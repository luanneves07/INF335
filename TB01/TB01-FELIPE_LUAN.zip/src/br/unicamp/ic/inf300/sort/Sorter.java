package br.unicamp.ic.inf300.sort;

public abstract class Sorter {

	public Sorter() {
		super();
	}

	public void sort(int[] vector) { };
}
